#include <iostream>
using namespace std;

int main ()
  {
    string s, a;
    cout << "Please enter a text with hyphen: ";
    cin >> s;
    for(int i=0;i<s.length();i++)
    {
        if(s[i]=='-')
        {
            cout<<a;
            a="";
            i++;
            cout<<endl;
        }
        a=a+s[i];
    }
    cout<<a;

    return 0;
}
