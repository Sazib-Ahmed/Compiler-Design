# include <stdio.h>

int main()
{
    FILE *fp ;
    char data[100] ;
    printf("Opening the file student.txt in read mode.\n\n");
    fp = fopen("student.txt", "r") ;

    if ( fp == NULL )
    {
        printf("Could not open file student.txt\n");
        return 0;
    }

    printf("Reading the file student.txt\n") ;
    while( fgets ( data, 50, fp ) != NULL )
        printf( "%s" , data ) ;

    printf("\n\nClosing the file student.txt\n") ;
    fclose(fp) ;
    return 0;
}
