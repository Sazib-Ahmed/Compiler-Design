#include <stdio.h>

int main()
{
    char name[50];
    int marks, i, num;
    printf("Enter number of students: ");
    scanf("%d", &num);

    FILE *fptr;
    printf("Opening the file student.txt in append mode.\n\n");
    fptr = (fopen("student.txt", "a"));

    if(fptr == NULL)
    {
        printf("Could not open file student.txt\n");
        return 0;
    }

    for(i = 0; i < num; ++i)
    {
        printf("For student%d\nEnter name: ", i+1);
        scanf("%s", name);
        printf("Enter marks: ");
        scanf("%d", &marks);
        fprintf(fptr,"Name: %s \nMarks: %d \n", name, marks);
    }

    printf("\n\nClosing the file student.txt\n");
    fclose(fptr) ;
    return 0;
}
