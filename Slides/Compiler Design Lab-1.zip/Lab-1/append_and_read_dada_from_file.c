/*To create a .txt file that will store some student names and obtained marks*/
#include <stdio.h>
int main()
{
   char name[50];
   int marks, i, num;
   printf("Enter number of students: ");
   scanf("%d", &num);

   FILE *fptr;
   printf("Opening the file student.txt in append mode.\n\n");
   fptr = (fopen("student.txt", "a"));

   if(fptr == NULL)
   {
       printf("Could not open file student.txt\n");
        return 0;
   }

   for(i = 0; i < num; ++i)
   {
      printf("For student%d\nEnter name: ", i+1);
      scanf("%s", name);
      printf("Enter marks: ");
      scanf("%d", &marks);

      fprintf(fptr,"Name: %s Marks: %d \n", name, marks);
   }
   printf("\nClosing the file student.txt\n");
   fclose(fptr) ;
   /*now, read the student.txt file and show the information
   in the console(output screen)*/

    char data[500];
    printf("\nOpening the file student.txt in read mode");
    fptr = fopen( "student.txt", "r" );
    printf("Reading the file student.txt\n");

    while( fgets ( data, 500, fptr ) != NULL )
        printf("%s" , data) ;

    printf("\nClosing the file student.txt\n");
    fclose(fptr);
    return 0;
}
